package com.example.flutter_food_delivery_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
